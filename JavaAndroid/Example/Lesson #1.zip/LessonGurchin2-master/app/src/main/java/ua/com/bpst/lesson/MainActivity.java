package ua.com.bpst.lesson;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button bt_start;

    public Click listener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt_start = (Button)findViewById(R.id.bt_start);
        bt_start.setOnClickListener(onButtonClick);
    }

    View.OnClickListener onButtonClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            listener.onClick2(view);

            Intent second = new Intent(MainActivity.this, SecondActivity.class);
            startActivityForResult(second, 20);

            bt_start.setEnabled(false);
        }
    };

    interface Click{
        void onClick2(View v);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 20 && requestCode == RESULT_OK){
            if(data.hasExtra("name")){
                String  name = data.getStringExtra("name");
            }
        }
    }
}
